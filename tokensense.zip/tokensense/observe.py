import os
import time
from typing import Any, Dict, List, Optional
from tokensense.cost import calculate_cost
from tokensense.outputs import BaseOutput, Stdout, SQLite, Logger, Multi

def get_default_output() -> BaseOutput:
    env = os.environ.get("ENV") or os.environ.get("PYTHON_ENV")
    if env == "production":
        return Logger("tokensense")
    else:
        return Multi(Stdout(), SQLite("./tokensense.db"))

class ObservedMethodWrapper:
    def __init__(
        self, 
        original_method: Any, 
        output: BaseOutput, 
        log_prompts: bool, 
        log_responses: bool, 
        meta_kwargs: Dict[str, Any]
    ):
        self.original_method = original_method
        self.output = output
        self.log_prompts = log_prompts
        self.log_responses = log_responses
        self.meta_kwargs = meta_kwargs

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        start_time = time.time()
        status = "success"
        response = None
        error_msg = None
        
        # Capture input / prompt content if logged
        prompt_content = None
        if self.log_prompts:
            # Look inside kwargs or args for messages / prompt
            messages = kwargs.get("messages") or (args[0] if args and isinstance(args[0], list) else None)
            if messages:
                prompt_content = str(messages)
            else:
                prompt_content = kwargs.get("prompt") or (args[0] if args and isinstance(args[0], str) else None)

        try:
            response = self.original_method(*args, **kwargs)
            return response
        except Exception as e:
            status = "error"
            error_msg = str(e)
            raise e
        finally:
            latency_ms = (time.time() - start_time) * 1000.0
            
            # Extract metrics from response
            model = kwargs.get("model", "unknown")
            input_tokens = 0
            output_tokens = 0
            response_content = None

            if status == "success" and response is not None:
                # Try getting model from response first
                if hasattr(response, "model"):
                    model = response.model
                
                # Check OpenAI style usage
                if hasattr(response, "usage") and response.usage:
                    usage = response.usage
                    if hasattr(usage, "prompt_tokens"):
                        input_tokens = getattr(usage, "prompt_tokens", 0) or 0
                    elif hasattr(usage, "input_tokens"):
                        input_tokens = getattr(usage, "input_tokens", 0) or 0
                    
                    if hasattr(usage, "completion_tokens"):
                        output_tokens = getattr(usage, "completion_tokens", 0) or 0
                    elif hasattr(usage, "output_tokens"):
                        output_tokens = getattr(usage, "output_tokens", 0) or 0

                # Extract response text if logged
                if self.log_responses:
                    if hasattr(response, "choices") and response.choices:
                        try:
                            choice = response.choices[0]
                            if hasattr(choice, "message") and hasattr(choice.message, "content"):
                                response_content = choice.message.content
                        except Exception:
                            pass
                    elif hasattr(response, "content") and response.content:
                        # Anthropic style content
                        if isinstance(response.content, list):
                            response_content = "".join([getattr(c, "text", "") for c in response.content])
                        else:
                            response_content = str(response.content)

            cost = calculate_cost(model, input_tokens, output_tokens)

            # Package standard payload
            log_payload = {
                "timestamp": start_time,
                "model": model,
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "cost": cost,
                "latency_ms": latency_ms,
                "status": status,
                **self.meta_kwargs
            }
            if self.log_prompts and prompt_content:
                log_payload["prompt"] = prompt_content
            if self.log_responses and response_content:
                log_payload["response"] = response_content
            if error_msg:
                log_payload["error"] = error_msg

            self.output.write(log_payload)

class ObservedAsyncMethodWrapper(ObservedMethodWrapper):
    async def __call__(self, *args: Any, **kwargs: Any) -> Any:
        start_time = time.time()
        status = "success"
        response = None
        error_msg = None
        
        prompt_content = None
        if self.log_prompts:
            messages = kwargs.get("messages") or (args[0] if args and isinstance(args[0], list) else None)
            if messages:
                prompt_content = str(messages)
            else:
                prompt_content = kwargs.get("prompt") or (args[0] if args and isinstance(args[0], str) else None)

        try:
            response = await self.original_method(*args, **kwargs)
            return response
        except Exception as e:
            status = "error"
            error_msg = str(e)
            raise e
        finally:
            latency_ms = (time.time() - start_time) * 1000.0
            
            model = kwargs.get("model", "unknown")
            input_tokens = 0
            output_tokens = 0
            response_content = None

            if status == "success" and response is not None:
                if hasattr(response, "model"):
                    model = response.model
                
                if hasattr(response, "usage") and response.usage:
                    usage = response.usage
                    if hasattr(usage, "prompt_tokens"):
                        input_tokens = getattr(usage, "prompt_tokens", 0) or 0
                    elif hasattr(usage, "input_tokens"):
                        input_tokens = getattr(usage, "input_tokens", 0) or 0
                    
                    if hasattr(usage, "completion_tokens"):
                        output_tokens = getattr(usage, "completion_tokens", 0) or 0
                    elif hasattr(usage, "output_tokens"):
                        output_tokens = getattr(usage, "output_tokens", 0) or 0

                if self.log_responses:
                    if hasattr(response, "choices") and response.choices:
                        try:
                            choice = response.choices[0]
                            if hasattr(choice, "message") and hasattr(choice.message, "content"):
                                response_content = choice.message.content
                        except Exception:
                            pass
                    elif hasattr(response, "content") and response.content:
                        if isinstance(response.content, list):
                            response_content = "".join([getattr(c, "text", "") for c in response.content])
                        else:
                            response_content = str(response.content)

            cost = calculate_cost(model, input_tokens, output_tokens)

            log_payload = {
                "timestamp": start_time,
                "model": model,
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "cost": cost,
                "latency_ms": latency_ms,
                "status": status,
                **self.meta_kwargs
            }
            if self.log_prompts and prompt_content:
                log_payload["prompt"] = prompt_content
            if self.log_responses and response_content:
                log_payload["response"] = response_content
            if error_msg:
                log_payload["error"] = error_msg

            self.output.write(log_payload)

class ObjectProxy:
    def __init__(
        self, 
        obj: Any, 
        output: BaseOutput, 
        log_prompts: bool, 
        log_responses: bool, 
        meta_kwargs: Dict[str, Any]
    ):
        self._obj = obj
        self._output = output
        self._log_prompts = log_prompts
        self._log_responses = log_responses
        self._meta_kwargs = meta_kwargs

    def __getattr__(self, name: str) -> Any:
        attr = getattr(self._obj, name)
        
        # Check if it's a method we want to wrap
        # Typically chat.completions.create, messages.create
        if callable(attr):
            # If it's a method named 'create', wrap it
            if name == "create":
                # Check if it's async (coroutines / async methods)
                import inspect
                if inspect.iscoroutinefunction(attr):
                    return ObservedAsyncMethodWrapper(
                        attr, self._output, self._log_prompts, self._log_responses, self._meta_kwargs
                    )
                else:
                    return ObservedMethodWrapper(
                        attr, self._output, self._log_prompts, self._log_responses, self._meta_kwargs
                    )
            return attr
        
        # If it's an object, wrap it in a proxy as well so we catch nested calls like client.chat.completions.create
        if hasattr(attr, "__dict__") or isinstance(attr, object):
            return ObjectProxy(
                attr, self._output, self._log_prompts, self._log_responses, self._meta_kwargs
            )
        return attr

def observe(
    client: Any,
    output: Optional[BaseOutput] = None,
    log_prompts: bool = False,
    log_responses: bool = False,
    **kwargs: Any
) -> Any:
    """
    Wrap an LLM client (e.g. OpenAI, Anthropic, Groq) to observe, record, and cost-track call invocations.
    """
    if output is None:
        output = get_default_output()
        
    return ObjectProxy(client, output, log_prompts, log_responses, kwargs)
