# Model pricing details per 1M tokens
MODEL_PRICING = {
    # OpenAI
    "gpt-4o": {"input": 5.00, "output": 15.00},
    "gpt-4o-mini": {"input": 0.15, "output": 0.60},
    # Anthropic
    "claude-sonnet-4-6": {"input": 3.00, "output": 15.00},
    "claude-haiku-4-5": {"input": 0.25, "output": 1.25},
    # Groq (and llama3 patterns)
    "llama3-8b": {"input": 0.05, "output": 0.10},
    "groq/llama3-8b": {"input": 0.05, "output": 0.10},
}

def calculate_cost(model_name: str, input_tokens: int, output_tokens: int) -> float:
    """
    Calculate the USD cost of an LLM invocation based on input and output tokens.
    """
    # Try exact match, then prefix/substring matches
    pricing = None
    for pattern, price in MODEL_PRICING.items():
        if pattern in model_name:
            pricing = price
            break
            
    if not pricing:
        # Fallback to standard/average pricing if unknown
        pricing = {"input": 0.15, "output": 0.60}
        
    input_cost = (input_tokens / 1_000_000.0) * pricing["input"]
    output_cost = (output_tokens / 1_000_000.0) * pricing["output"]
    return input_cost + output_cost
