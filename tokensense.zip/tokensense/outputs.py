import json
import logging
import sqlite3
import time
from typing import List, Dict, Any, Optional

class BaseOutput:
    def write(self, data: Dict[str, Any]) -> None:
        raise NotImplementedError("Subclasses must implement write")

class Stdout(BaseOutput):
    def write(self, data: Dict[str, Any]) -> None:
        status_indicator = "✅" if data.get("status") == "success" else "❌"
        meta_str = (
            f"model={data.get('model')} | "
            f"in={data.get('input_tokens')} out={data.get('output_tokens')} tokens | "
            f"${data.get('cost', 0.0):.6f} | "
            f"{data.get('latency_ms', 0):.0f}ms {status_indicator}"
        )
        print(f"→ {meta_str}")
        if data.get("prompt"):
            print(f"  [Prompt] {data.get('prompt')}")
        if data.get("response"):
            print(f"  [Response] {data.get('response')}")

class SQLite(BaseOutput):
    def __init__(self, db_path: str = "./tokensense.db"):
        self.db_path = db_path
        self._init_db()

    def _init_db(self) -> None:
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS usage_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp REAL,
                model TEXT,
                input_tokens INTEGER,
                output_tokens INTEGER,
                cost REAL,
                latency_ms REAL,
                status TEXT,
                prompt TEXT,
                response TEXT,
                user_id TEXT,
                session_id TEXT,
                tags TEXT
            )
        """)
        conn.commit()
        conn.close()

    def write(self, data: Dict[str, Any]) -> None:
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO usage_logs (
                timestamp, model, input_tokens, output_tokens, cost, 
                latency_ms, status, prompt, response, user_id, session_id, tags
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            data.get("timestamp", time.time()),
            data.get("model"),
            data.get("input_tokens"),
            data.get("output_tokens"),
            data.get("cost"),
            data.get("latency_ms"),
            data.get("status"),
            data.get("prompt"),
            data.get("response"),
            data.get("user_id"),
            data.get("session_id"),
            json.dumps(data.get("tags", [])) if data.get("tags") is not None else None
        ))
        conn.commit()
        conn.close()

class Logger(BaseOutput):
    def __init__(self, logger_name: str = "tokensense"):
        self.logger = logging.getLogger(logger_name)
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)

    def write(self, data: Dict[str, Any]) -> None:
        log_message = json.dumps(data)
        if data.get("status") == "success":
            self.logger.info(log_message)
        else:
            self.logger.error(log_message)

class HTTP(BaseOutput):
    def __init__(self, url: str):
        self.url = url

    def write(self, data: Dict[str, Any]) -> None:
        # In-process background POST or simple synchronous call
        import urllib.request
        req_data = json.dumps(data).encode("utf-8")
        req = urllib.request.Request(
            self.url,
            data=req_data,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        try:
            # Short timeout to not block too long
            with urllib.request.urlopen(req, timeout=2.0) as response:
                response.read()
        except Exception as e:
            # Silent fail or log failure to stderr to not crash client flow
            pass

class Multi(BaseOutput):
    def __init__(self, *outputs: BaseOutput):
        self.outputs = list(outputs)

    def write(self, data: Dict[str, Any]) -> None:
        for output in self.outputs:
            try:
                output.write(data)
            except Exception:
                pass
