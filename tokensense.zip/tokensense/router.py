import logging
from typing import Any, Dict, List, Optional, Union

logger = logging.getLogger("tokensense.router")

def estimate_tokens(messages: List[Dict[str, Any]]) -> int:
    """
    Rough estimation of tokens in messages. Falls back to character length / 4.
    """
    total_chars = 0
    for msg in messages:
        content = msg.get("content", "")
        if isinstance(content, str):
            total_chars += len(content)
        elif isinstance(content, list):
            for part in content:
                if isinstance(part, dict) and "text" in part:
                    total_chars += len(part["text"])
    return total_chars // 4

class Router:
    def __init__(
        self,
        tiers: Dict[str, List[str]],
        rules: List[Dict[str, Any]],
        on_failure: str = "escalate",
        clients: Optional[Dict[str, Any]] = None
    ):
        self.tiers = tiers
        self.rules = rules
        self.on_failure = on_failure
        self.clients = clients or {}

    def register_client(self, provider_or_model: str, client: Any) -> None:
        """
        Register a client for a specific provider (e.g., 'openai', 'anthropic', 'groq') or model prefix.
        """
        self.clients[provider_or_model] = client

    def _get_client_for_model(self, model: str) -> Any:
        # Check direct model match first
        if model in self.clients:
            return self.clients[model]
        
        # Check provider match
        if "/" in model:
            provider = model.split("/")[0]
            if provider in self.clients:
                return self.clients[provider]
        
        if model.startswith("gpt-") and "openai" in self.clients:
            return self.clients["openai"]
        if model.startswith("claude-") and "anthropic" in self.clients:
            return self.clients["anthropic"]
        if ("llama" in model or "groq" in model) and "groq" in self.clients:
            return self.clients["groq"]

        # Default fallback: return first client
        if self.clients:
            return list(self.clients.values())[0]
        
        raise ValueError(f"No client registered that can handle model '{model}'")

    def select_tier_and_model(
        self, 
        context_tokens: int, 
        task_hint: Optional[str] = None
    ) -> List[str]:
        """
        Select sorted list of candidate models to try based on routing rules and context/task.
        """
        denied_tiers = set()
        pinned_tier = None

        # Evaluate rules
        for rule in self.rules:
            # Check context token rule
            if "if_context_tokens_gt" in rule:
                if context_tokens > rule["if_context_tokens_gt"]:
                    if "deny_tiers" in rule:
                        denied_tiers.update(rule["deny_tiers"])
                    if "pin_tier" in rule:
                        pinned_tier = rule["pin_tier"]
            
            # Check task rule
            if "if_task" in rule and task_hint:
                if rule["if_task"] == task_hint:
                    if "deny_tiers" in rule:
                        denied_tiers.update(rule["deny_tiers"])
                    if "pin_tier" in rule:
                        pinned_tier = rule["pin_tier"]

        # Resolve tier candidates
        eligible_tiers = []
        if pinned_tier and pinned_tier in self.tiers and pinned_tier not in denied_tiers:
            eligible_tiers = [pinned_tier]
        else:
            # Order tiers by cost heuristic: small first, large second
            ordered_tiers = []
            if "small" in self.tiers:
                ordered_tiers.append("small")
            if "large" in self.tiers:
                ordered_tiers.append("large")
            # add any other tiers
            for tier in self.tiers:
                if tier not in ordered_tiers:
                    ordered_tiers.append(tier)
            
            eligible_tiers = [t for t in ordered_tiers if t not in denied_tiers]

        # Gather models
        candidate_models = []
        for tier in eligible_tiers:
            candidate_models.extend(self.tiers[tier])
            
        return candidate_models

    def create(
        self,
        messages: List[Dict[str, Any]],
        task_hint: Optional[str] = None,
        max_cost_usd: Optional[float] = None,
        **kwargs: Any
    ) -> Any:
        """
        Route and execute the LLM completion using the best matching model.
        """
        context_tokens = estimate_tokens(messages)
        candidate_models = self.select_tier_and_model(context_tokens, task_hint)
        
        if not candidate_models:
            raise ValueError("No eligible models found after applying routing rules")

        last_error = None
        for i, model in enumerate(candidate_models):
            # Check if this model exceeds cost budget estimate (could skip if we had strict pricing info)
            try:
                client = self._get_client_for_model(model)
                logger.info(f"Routing call to model: {model}")
                
                # Execute depending on client type
                # Standardize model argument mapping (e.g. Anthropic uses 'model', OpenAI uses 'model')
                # For Groq or others, remove prefix 'groq/' if present when calling client
                clean_model_name = model
                if "/" in model:
                    parts = model.split("/")
                    # If provider name matched Groq, clean it
                    if parts[0] == "groq":
                        clean_model_name = parts[1]

                # Invoke the appropriate method depending on client type
                if hasattr(client, "messages") and hasattr(client.messages, "create"):
                    # Anthropic style
                    res = client.messages.create(
                        model=clean_model_name,
                        messages=messages,
                        **kwargs
                    )
                    return res
                elif hasattr(client, "chat") and hasattr(client.chat, "completions") and hasattr(client.chat.completions, "create"):
                    # OpenAI style
                    res = client.chat.completions.create(
                        model=clean_model_name,
                        messages=messages,
                        **kwargs
                    )
                    return res
                else:
                    # Generic fallback if custom client wrapper or direct callable
                    res = client(model=clean_model_name, messages=messages, **kwargs)
                    return res

            except Exception as e:
                logger.warning(f"Model {model} failed: {e}")
                last_error = e
                if self.on_failure != "escalate":
                    raise e
                    
        raise RuntimeError(f"All routed models failed. Last error: {last_error}")

    async def acreate(
        self,
        messages: List[Dict[str, Any]],
        task_hint: Optional[str] = None,
        max_cost_usd: Optional[float] = None,
        **kwargs: Any
    ) -> Any:
        """
        Async version to route and execute the LLM completion.
        """
        context_tokens = estimate_tokens(messages)
        candidate_models = self.select_tier_and_model(context_tokens, task_hint)
        
        if not candidate_models:
            raise ValueError("No eligible models found after applying routing rules")

        last_error = None
        for i, model in enumerate(candidate_models):
            try:
                client = self._get_client_for_model(model)
                logger.info(f"Routing async call to model: {model}")
                
                clean_model_name = model
                if "/" in model:
                    parts = model.split("/")
                    if parts[0] == "groq":
                        clean_model_name = parts[1]

                if hasattr(client, "messages") and hasattr(client.messages, "create"):
                    res = await client.messages.create(
                        model=clean_model_name,
                        messages=messages,
                        **kwargs
                    )
                    return res
                elif hasattr(client, "chat") and hasattr(client.chat, "completions") and hasattr(client.chat.completions, "create"):
                    res = await client.chat.completions.create(
                        model=clean_model_name,
                        messages=messages,
                        **kwargs
                    )
                    return res
                else:
                    res = await client(model=clean_model_name, messages=messages, **kwargs)
                    return res

            except Exception as e:
                logger.warning(f"Async model {model} failed: {e}")
                last_error = e
                if self.on_failure != "escalate":
                    raise e
                    
        raise RuntimeError(f"All routed models failed. Last error: {last_error}")
